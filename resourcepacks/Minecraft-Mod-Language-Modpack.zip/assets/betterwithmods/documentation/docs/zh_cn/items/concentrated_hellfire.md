![浓缩炼狱之火锭](item:betterwithmods:material@17)

浓缩炼狱之火锭可由在[釜锅](../blocks/cauldron.md)加工大量[炼狱之火粉尘](hellfire_dust.md)获得,
  
可用于制作[碳炉](../blocks/hibachi.md)等热源.
